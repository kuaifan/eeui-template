<template>

    <div class="app">

        <scroller class="menu">
            <div v-for="(item, index) in lists" :key="index" :class="[active === index ? 'menu-item-active' : 'menu-item']" @click="selectMenu(index)">
                <image v-if="item.type===1" class="menu-item-label" src="../assets/images/supports/b1.png"></image>
                <image v-else-if="item.type===2" class="menu-item-label" src="../assets/images/supports/b2.png"></image>
                <text class="menu-item-text">{{item.name}}</text>
            </div>
            <div class="bottom-placeholder"></div>
        </scroller>

        <scroll-view ref="myScroll" class="food">
            <template v-for="(item, index) in lists">
                <scroll-header class="food-layer" @stateChanged="stateChanged(index, $event)">
                    <text class="food-layer-text">{{item.name}}</text>
                </scroll-header>
                <div v-for="(foods, findex) in item.foods" :class="[findex === 0 ? 'food-item-first' : 'food-item']">
                    <image class="food-item-picture" :src="foods.icon"></image>
                    <div class="food-item-info">
                        <text class="food-item-title">{{foods.name}}</text>
                        <text v-if="foods.description" class="food-item-desc">{{foods.description}}</text>
                        <text class="food-item-extra">月售{{foods.sellCount}}份  好评率{{foods.rating}}%</text>
                        <div class="food-item-price">
                            <text class="food-item-money">￥{{foods.price}}</text>
                            <icon v-if="foods.selectNum > 0" class="food-item-remove" content="md-remove-circle-outline" @click="$set(foods, 'selectNum', foods.selectNum - 1),calculate()"></icon>
                            <text v-if="foods.selectNum > 0" class="food-item-number">{{foods.selectNum}}</text>
                            <icon class="food-item-add" content="md-add-circle" @click="$set(foods, 'selectNum', foods.selectNum + 1),calculate()"></icon>
                        </div>
                    </div>
                </div>
            </template>
            <div class="bottom-placeholder"></div>
        </scroll-view>

        <div v-if="cartShow" class="cart" @click="cartShow=false">
            <div class="cart-head" @click.stop="">
                <text class="cart-head-title">购物车</text>
                <text class="cart-head-clear" @click="cartClear">清空</text>
            </div>
            <div class="cart-list" @click.stop="">
                <template v-for="item in lists">
                    <div v-for="(foods, findex) in item.foods" v-if="foods.selectNum > 0" :class="[findex === 0 ? 'cart-item-first' : 'cart-item']">
                        <text class="cart-item-title">{{foods.name}}</text>
                        <text class="cart-item-money">￥{{foods.price * foods.selectNum}}</text>
                        <div class="cart-item-price">
                            <icon class="cart-item-remove" content="md-remove-circle-outline" @click="$set(foods, 'selectNum', foods.selectNum - 1),calculate()"></icon>
                            <text class="cart-item-number">{{foods.selectNum}}</text>
                            <icon class="cart-item-add" content="md-add-circle" @click="$set(foods, 'selectNum', foods.selectNum + 1),calculate()"></icon>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <div class="bottom" @click="cartMoney > 0 ? cartShow = !cartShow : ''">
            <div class="bottom-info">
                <text :class="[cartNum > 0 ? 'bottom-info-price' : 'bottom-info-price-not']">￥{{cartMoney}}</text>
                <text class="bottom-info-desc">{{ sellerInfo.deliveryPrice > 0 ? ('另需配送费￥' + sellerInfo.deliveryPrice + '元') : '免配送费'}}</text>
                <text v-if="cartMoney < sellerInfo.minPrice" class="bottom-info-button-not">￥{{sellerInfo.minPrice}}元起送</text>
                <text v-else class="bottom-info-button" @click.stop="cartCheck">去结算</text>
            </div>
            <div class="bottom-box-cart">
                <div class="bottom-box-cart-bg"></div>
                <icon :class="[cartNum > 0 ? 'bottom-box-cart-icon' : 'bottom-box-cart-icon-not']" content="tb-cart-fill"></icon>
                <text v-if="cartNum > 0" class="bottom-box-cart-num">{{cartNum}}</text>
            </div>
        </div>

    </div>

</template>

<style scoped>
    .app {
        flex: 1;
        flex-direction: row;
    }
    .menu {
        flex: 2;
        background-color: #f3f5f7;
    }
    .menu-item,
    .menu-item-active {
        flex-direction: row;
        align-items: center;
        justify-content: center;
        padding: 0 20px;
        height: 112px;
        background-color: #f3f5f7;
    }
    .menu-item-active {
        background-color: #ffffff;
    }
    .menu-item-label {
        width: 24px;
        height: 24px;
        margin-right: 6px;
    }
    .menu-item-text {
        flex: 1;
        color: #666666;
        text-align: center;
        font-size: 24px;
        text-overflow: ellipsis;
        lines: 2;
    }
    .food {
        flex: 7;
    }
    .food-layer {
        justify-content: center;
        background-color: #f3f5f7;
        border-left-width: 4px;
        border-left-style: solid;
        border-left-color: #d9dde1;
        height: 52px;
    }
    .food-layer-text {
        color: #666666;
        font-size: 24px;
        padding-left: 28px;
    }
    .food-item,
    .food-item-first {
        flex-direction: row;
        align-items: flex-start;
        padding: 0 32px 32px 32px;
    }
    .food-item-first {
        padding-top: 32px;
    }
    .food-item-picture {
        width: 114px;
        height: 114px;
        margin-top: 12px;
        margin-right: 20px;
    }
    .food-item-info {
        flex: 1;
    }
    .food-item-title {
        color: #333333;
        font-size: 28px;
        margin-top: 4px;
    }
    .food-item-desc {
        color: #999999;
        font-size: 22px;
        margin-top: 4px;
    }
    .food-item-extra {
        color: #999999;
        font-size: 22px;
        margin-top: 4px;
    }
    .food-item-price {
        flex-direction: row;
        align-items: center;
    }
    .food-item-money {
        flex: 1;
        color: #f01414;
        font-size: 28px;
        margin-right: 16px;
    }
    .food-item-remove,
    .food-item-add {
        font-size: 48px;
        width: 72px;
        height: 72px;
        color: #00a0dc;
    }
    .food-item-number {
        color: #666666;
        font-size: 26px;
        text-align: center;
        padding: 0 3px;
    }
    .bottom {
        position: absolute;
        left: 0;
        bottom: 0;
        width: 750px;
        height: 132px;
        justify-content: flex-end;
    }
    .bottom-placeholder {
        width: 750px;
        height: 112px;
    }
    .bottom-box-cart {
        position: absolute;
        left: 24px;
        top: 0;
        width: 132px;
        height: 132px;
    }
    .bottom-box-cart-bg {
        position: absolute;
        top: 0;
        right: 0;
        width: 132px;
        height: 132px;
        background-color: #07111b;
        border-radius: 66px;
    }
    .bottom-box-cart-icon,
    .bottom-box-cart-icon-not {
        margin-top: 10px;
        margin-left: 10px;
        width: 112px;
        height: 112px;
        border-radius: 56px;
        font-size: 52px;
        background-color: #00a0dc;
        color: #ffffff;
    }
    .bottom-box-cart-icon-not {
        background-color: #333333;
        color: #999999;
    }
    .bottom-box-cart-num {
        position: absolute;
        top: 0;
        right: 2px;
        font-size: 26px;
        text-align: center;
        padding: 0 11px;
        height: 36px;
        line-height: 36px;
        color: #ffffff;
        background-color: #ff0000;
        border-radius: 18px;
    }
    .bottom-info {
        flex-direction: row;
        align-items: center;
        padding-left: 176px;
        height: 112px;
        background-color: #07111b;
    }
    .bottom-info-price,
    .bottom-info-price-not {
        color: #ffffff;
        font-size: 34px;
        font-weight: 600;
        padding-right: 20px;
    }
    .bottom-info-price-not {
        color: #999999;
    }
    .bottom-info-desc {
        flex: 1;
        border-left-width: 2px;
        border-left-style: solid;
        border-left-color: #0b1b2b;
        padding-left: 20px;
        font-size: 24px;
        color: #999999;
    }
    .bottom-info-button,
    .bottom-info-button-not {
        background-color: #00b43c;
        color: #ffffff;
        font-weight: 600;
        width: 210px;
        height: 112px;
        line-height: 112px;
        text-align: center;
        font-size: 24px;
    }
    .bottom-info-button-not {
        background-color: #333333;
        color: #999999;
    }
    .cart {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 112px;
        justify-content: flex-end;
        background-color: rgba(7, 17, 27, 0.6);
    }
    .cart-head {
        flex-direction: row;
        align-items: center;
        background-color: #f3f5f7;
        height: 80px;
        padding: 0 36px;
    }
    .cart-head-title {
        flex: 1;
        color: #333333;
        font-size: 28px;
    }
    .cart-head-clear {
        color: #00a0dc;
        font-size: 26px;
    }
    .cart-list {
        background-color: #ffffff;
    }
    .cart-item,
    .cart-item-first {
        flex-direction: row;
        align-items: center;
        height: 96px;
        margin: 0 36px;
        border-top-width: 1px;
        border-top-style: solid;
        border-top-color: rgba(28, 70, 110, 0.1);
    }
    .cart-item-first {
        border-top-width: 0;
    }
    .cart-item-title {
        flex: 1;
        color: #333333;
        font-size: 28px;
    }
    .cart-item-money {
        color: #f01414;
        font-size: 30px;
        margin-right: 16px;
    }
    .cart-item-price {
        flex-direction: row;
        align-items: center;
    }
    .cart-item-remove,
    .cart-item-add {
        font-size: 48px;
        width: 72px;
        height: 72px;
        color: #00a0dc;
    }
    .cart-item-number {
        color: #666666;
        font-size: 26px;
        text-align: center;
        padding: 0 3px;
    }
</style>
<script>
    const eeui = app.requireModule('eeui');

    export default {
        data() {
            return {
                sellerInfo: {},

                active: 0,
                lists: [],

                cartShow: false,
                cartNum: 0,
                cartMoney: 0,
            }
        },

        created() {
            try {
                this.sellerInfo = JSON.parse(eeui.getVariate("sellerInfo", "{}"));
            }catch (e) {

            }
            //
            eeui.ajax({
                url: eeui.rewriteUrl("../assets/json/goods.json"),
            }, (result) => {
                if (result.status === "success") {
                    let res = result.result;
                    if (res.ret === 1) {
                        this.lists = res.data;
                    } else {
                        eeui.alert({
                            title: "温馨提示",
                            message: "加载商品列表失败！",
                        });
                    }
                }
            });
        },

        methods: {
            selectMenu(index) {
                let position = 0;
                for (let i = 0; i < this.lists.length; i++) {
                    if (i === index) {
                        break;
                    }
                    position+= this.lists[i].foods.length + 1;
                }
                this.active = index;
                this.$refs.myScroll.scrollToPosition(position);
            },

            stateChanged(index, data) {
                if (data.status === "float") {
                    this.active = index;
                }
            },

            calculate() {
                let number = 0;
                let money = 0;
                for (let i = 0; i < this.lists.length; i++) {
                    let foods = this.lists[i].foods;
                    for (let j = 0; j < foods.length; j++) {
                        number+= foods[j].selectNum;
                        money+= foods[j].selectNum * foods[j].price;
                    }
                }
                this.cartNum = number;
                this.cartMoney = money;
            },

            cartClear() {
                for (let i = 0; i < this.lists.length; i++) {
                    let foods = this.lists[i].foods;
                    for (let j = 0; j < foods.length; j++) {
                        if (foods[j].selectNum > 0) {
                            this.$set(foods[j], 'selectNum', 0);
                        }
                    }
                }
                this.cartNum = 0;
                this.cartMoney = 0;
                this.cartShow = false;
            },

            cartCheck() {
                this.calculate();
                eeui.alert({
                    title: "支付提示",
                    message: "您需要支付" + this.cartMoney + "元",
                });
            }
        }
    }
</script>
