<template>

    <div class="app">

        <div class="header" @click="showDetail=true">
            <image class="header-image" :src="sellerInfo.avatar" resize="cover"></image>
            <div class="header-box">
                <image class="header-avatar" :src="sellerInfo.avatar" resize="cover"></image>
                <div class="header-info">
                    <div class="header-title">
                        <image class="header-title-brand" src="../assets/images/brand.png"></image>
                        <text class="header-title-name">{{sellerInfo.name}}</text>
                    </div>
                    <text class="header-desc">{{sellerInfo.description}}/{{sellerInfo.deliveryTime}}分钟送达</text>
                    <div v-if="handleLength(sellerInfo.supports) > 0" class="header-support">
                        <image class="header-support-icon" :src="'../assets/images/supports/' + sellerInfo.supports[0].type + '.png'"></image>
                        <text class="header-support-text">{{sellerInfo.supports[0].description}}</text>
                        <div class="header-support-count">
                            <text class="header-support-count-text">{{handleLength(sellerInfo.supports)}}个</text>
                            <icon class="header-support-count-icon" content="tb-right"></icon>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bulletin">
                <image class="header-bulletin-notice" src="../assets/images/notice.png"></image>
                <text class="header-bulletin-text">{{sellerInfo.bulletin}}</text>
                <icon class="header-bulletin-icon" content="tb-right"></icon>
            </div>
        </div>

        <tabbar v-if="sellerLoaded" class="tabbar" :tabPages="tabPages" :eeui="tabConfig"></tabbar>

        <seller-detail v-model="showDetail" :sellerInfo="sellerInfo"></seller-detail>
    </div>

</template>

<style scoped>
    .app {
        flex: 1;
    }
    .header {
        position: relative;
    }
    .header-image {
        position: absolute;
        top: 0;
        left: 0;
        width: 750px;
        height: 272px;
    }
    .header-box {
        width: 750px;
        height: 216px;
        background-color: rgba(7,17,27,.8);
        flex-direction: row;
        align-items: center;
    }
    .header-avatar {
        margin-left: 48px;
        margin-right: 32px;
        width: 128px;
        height: 128px;
    }
    .header-info {
        flex: 1;
    }
    .header-title {
        flex-direction: row;
        align-items: center;
        margin-bottom: 8px;
    }
    .header-title-brand {
        width: 60px;
        height: 32px;
    }
    .header-title-name {
        color: #ffffff;
        padding-left: 12px;
        font-size: 32px;
    }
    .header-desc {
        color: #ffffff;
        font-size: 24px;
        margin-bottom: 6px;
    }
    .header-support {
        flex-direction: row;
        align-items: center;
    }
    .header-support-icon {
        width: 24px;
        height: 24px;
    }
    .header-support-text {
        flex: 1;
        color: #ffffff;
        font-size: 24px;
        padding-left: 8px;
    }
    .header-support-count {
        flex-direction: row;
        align-items: center;
        margin-right: 24px;
        background-color: rgba(7,17,27,.6);
        padding: 6px 18px;
        border-radius: 28px;
    }
    .header-support-count-text {
        color: #ffffff;
        font-size: 24px;
    }
    .header-support-count-icon {
        color: #ffffff;
        font-size: 24px;
        width: 24px;
        height: 24px;
        margin-left: 4px;
    }
    .header-bulletin {
        background-color: rgba(15, 39, 61, 0.8);
        flex-direction: row;
        align-items: center;
        width: 750px;
        height: 56px;
        padding-left: 16px;
        padding-right: 16px;
    }
    .header-bulletin-notice {
        margin-right: 8px;
        width: 44px;
        height: 24px;
    }
    .header-bulletin-text {
        flex: 1;
        font-size: 22px;
        color: #ffffff;
        text-overflow: ellipsis;
        lines: 1
    }
    .header-bulletin-icon {
        color: #ffffff;
        font-size: 22px;
        width: 20px;
        height: 20px;
        margin-left: 4px;
    }
    .tabbar {
        flex: 1;
        margin-bottom: -2px;
    }
</style>

<script>
    import SellerDetail from "../components/sellerDetail";
    const eeui = app.requireModule('eeui');

    export default {
        components: {SellerDetail},
        data() {
            return {
                sellerInfo: {},
                sellerLoaded: false,

                showDetail: false,

                tabPages: [{
                    title: '商品',
                    url: 'index-goods.js',
                }, {
                    title: '评论',
                    url: 'index-comment.js',
                }, {
                    title: '商家',
                    url: 'index-seller.js',
                }],

                tabConfig: {
                    tabType: "top",
                    tabHeight: "76px",
                    tabBackgroundColor: "#ffffff",
                    indicatorColor: "#ff0000",
                    indicatorWidth: "250px",
                    indicatorCornerRadius: "0",
                    underlineColor: "rgba(7,17,27,.1)",
                    underlineHeight: "1px",
                    textSelectColor: "#ff0000",
                    textUnselectColor: "#666666",
                    textSize: "26px",
                }
            }
        },

        created() {
            eeui.ajax({
                url: eeui.rewriteUrl("../assets/json/seller.json"),
            }, (result) => {
                if (result.status === "success") {
                    let res = result.result;
                    if (res.ret === 1) {
                        eeui.setVariate("sellerInfo", JSON.stringify(res.data));
                        this.sellerInfo = res.data;
                        this.sellerLoaded = true;
                    } else {
                        eeui.alert({
                            title: "温馨提示",
                            message: "数据加载失败！",
                        });
                    }
                }
            });
        },

        methods: {
            handleLength(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                if (typeof val !== "object") {
                    return 0;
                }
                return val.length || 0;
            },
        }
    };
</script>
