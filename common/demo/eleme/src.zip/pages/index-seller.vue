<template>

    <scroller class="seller">

        <div class="overview">
           <div class="overview-head">
               <div class="head-name">
                   <text class="name-title">{{sellerInfo.name}}</text>
                   <div class="name-star">
                       <image v-for="i in handleInt(sellerInfo.score)" class="star-star" src="../assets/images/star.png"></image>
                       <image v-for="i in 5 - handleInt(sellerInfo.score)" class="star-unstar"src="../assets/images/unstar.png"></image>
                       <text class="star-text">({{sellerInfo.ratingCount}})</text>
                       <text class="star-text">月销售{{sellerInfo.sellCount}}单</text>
                   </div>
               </div>
               <div class="head-favorite" @click="$set(sellerInfo, 'favorite', sellerInfo.favorite ? 0 : 1)">
                   <icon v-if="sellerInfo.favorite" class="favorite-icon" content="md-heart"></icon>
                   <icon v-else class="favorite-icon-empty" content="md-heart-empty"></icon>
                   <text class="favorite-text">{{ sellerInfo.favorite ? '已收藏' : '收藏' }}</text>
               </div>
           </div>
        </div>
        <div class="remark">
            <div class="remark-item">
                <text class="remark-item-title">起送价</text>
                <div class="remark-item-subtitle">
                    <text class="remark-item-value">{{sellerInfo.minPrice}}</text>
                    <text class="remark-item-unit">元</text>
                </div>
            </div>
            <div class="remark-line"></div>
            <div class="remark-item">
                <text class="remark-item-title">商家配送</text>
                <div class="remark-item-subtitle">
                    <text class="remark-item-value">{{sellerInfo.deliveryPrice}}</text>
                    <text class="remark-item-unit">元</text>
                </div>
            </div>
            <div class="remark-line"></div>
            <div class="remark-item">
                <text class="remark-item-title">平均配送时间</text>
                <div class="remark-item-subtitle">
                    <text class="remark-item-value">{{sellerInfo.deliveryTime}}</text>
                    <text class="remark-item-unit">分钟</text>
                </div>
            </div>
        </div>

        <div class="split"></div>
        <div class="bulletin">
            <text class="bulletin-title">公告与活动</text>
            <text class="bulletin-content">{{sellerInfo.bulletin}}</text>
            <div class="bulletin-supports">
                <div v-for="support in sellerInfo.supports" class="bulletin-supports-item">
                    <image class="bulletin-supports-item-icon" :src="'../assets/images/supports/b' + support.type + '.png'"></image>
                    <text class="bulletin-supports-item-text">{{support.description}}</text>
                </div>
            </div>
        </div>

        <template v-if="handleLength(sellerInfo.pics) > 0">
            <div class="split"></div>
            <div class="pics">
                <text class="pics-title">商家实景</text>
                <scroller class="pics-list" scroll-direction="horizontal">
                    <image class="pics-item" v-for="pic in sellerInfo.pics" :src="pic" resize="cover"></image>
                </scroller>
            </div>
        </template>

        <div class="split"></div>
        <div class="info">
            <text class="info-title">商家信息</text>
            <text class="info-item" v-for="info in sellerInfo.infos">{{info}}</text>
        </div>

    </scroller>

</template>

<style scoped>
    .overview {
        padding: 36px;
    }
    .overview-head {
        flex-direction: row;
        align-items: center;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(7, 17, 27, .1);
        padding-bottom: 36px;
    }
    .head-name {
        flex: 1;
    }
    .name-title {
        color: #333333;
        font-size: 28px;
        margin-bottom: 16px;
    }
    .name-star {
        flex-direction: row;
        align-items: center;
    }
    .star-star,
    .star-unstar {
        height: 30px;
        width: 30px;
        margin-right: 12px;
    }
    .star-text {
        color: #666666;
        font-size: 22px;
        margin-left: 12px;
        margin-right: 12px;
    }
    .head-favorite {
        width: 100px;
        margin-right: 22px;
        align-items: center;
        justify-content: center;
    }
    .favorite-icon,
    .favorite-icon-empty {
        width: 68px;
        height: 68px;
        color: #f01414;
        font-size: 58px;
    }
    .favorite-icon-empty {
        color: #cccccc;
    }
    .favorite-text {
        color: #666666;
        font-size: 24px;
    }
    .remark {
        flex-direction: row;
        align-items: center;
        padding-bottom: 36px;
    }
    .remark-item {
        flex: 1;
        justify-content: center;
        align-items: center;
    }
    .remark-item-title {
        color: #999999;
        font-size: 22px;
        margin-bottom: 8px;
    }
    .remark-item-subtitle {
        flex-direction: row;
        align-items: center;
    }
    .remark-item-value {
        color: #333333;
        font-size: 52px;
    }
    .remark-item-unit {
        color: #333333;
        font-size: 22px;
        padding-left: 4px;
        padding-top: 12px;
    }
    .remark-line {
        width: 1px;
        height: 58px;
        background-color: #d9dde1;
    }
    .split {
        background-color: #f3f5f7;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(7, 17, 27, .1);
        border-top-width: 1px;
        border-top-style: solid;
        border-top-color: rgba(7, 17, 27, .1);
        height: 32px;
        width: 750px;
    }
    .bulletin,
    .pics,
    .info {
        padding: 36px 36px 0;
    }
    .bulletin-title,
    .pics-title,
    .info-title {
        color: #333333;
        font-size: 28px;
        margin-bottom: 16px;
    }
    .bulletin-content {
        color: #f01414;
        font-size: 26px;
        line-height: 42px;
        padding: 0 24px 32px;
    }
    .bulletin-supports {

    }
    .bulletin-supports-item {
        border-top-width: 1px;
        border-top-style: solid;
        border-top-color: rgba(7, 17, 27, .1);
        flex-direction: row;
        align-items: center;
        padding: 32px 24px;
    }
    .bulletin-supports-item-icon {
        margin-right: 12px;
        height: 32px;
        width: 32px;
    }
    .bulletin-supports-item-text {
        font-size: 26px;
        color: #333333;
    }
    .pics-list {
        flex-direction: row;
        align-items: center;
    }
    .pics-item {
        width: 240px;
        height: 180px;
        margin-right: 12px;
    }
    .info-item {
        color: #333333;
        font-size: 26px;
        padding: 32px 24px;
        border-top-width: 1px;
        border-top-style: solid;
        border-top-color: rgba(7, 17, 27, .1);
    }
</style>
<script>
    const eeui = app.requireModule('eeui');

    export default {
        data() {
            return {
                sellerInfo: {},
            }
        },

        created() {
            try {
                this.sellerInfo = JSON.parse(eeui.getVariate("sellerInfo", "{}"));
            }catch (e) {

            }
        },

        methods: {
            handleLength(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                if (typeof val !== "object") {
                    return 0;
                }
                return val.length || 0;
            },

            handleInt(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                val = parseInt(val);
                if (isNaN(val)) {
                    return 0;
                }
                return val || 0;
            },
        }
    }
</script>
