<template>

    <scroller class="comment">

        <div class="overview">
            <div class="overview-left">
                <text class="overview-score">{{sellerInfo.score}}</text>
                <text class="overview-title">综合评分</text>
                <text class="overview-rank">高于周边商家{{sellerInfo.rankRate}}%</text>
            </div>
            <div class="overview-right">
                <div class="score-wrapper">
                    <text class="score-title">服务态度</text>
                    <image v-for="i in handleInt(sellerInfo.serviceScore)" class="score-star" src="../assets/images/star.png"></image>
                    <image v-for="i in 5 - handleInt(sellerInfo.serviceScore)" class="score-unstar"src="../assets/images/unstar.png"></image>
                    <text class="score-score">{{sellerInfo.serviceScore}}</text>
                </div>
                <div class="score-wrapper">
                    <text class="score-title">商品评分</text>
                    <image v-for="i in handleInt(sellerInfo.foodScore)" class="score-star" src="../assets/images/star.png"></image>
                    <image v-for="i in 5 - handleInt(sellerInfo.foodScore)" class="score-unstar"src="../assets/images/unstar.png"></image>
                    <text class="score-score">{{sellerInfo.foodScore}}</text>
                </div>
                <div class="score-wrapper">
                    <text class="score-title">送达时间</text>
                    <text class="score-delivery">平均{{sellerInfo.deliveryTime}}分钟</text>
                </div>
            </div>
        </div>

        <div class="split"></div>

        <div class="rating-select">
            <div class="rating-type">
                <text :class="[type === '' ? 'block-positive-active' : 'block-positive']" @click="type=''">全部{{total || ''}}</text>
                <text :class="[type === 'positive' ? 'block-positive-active' : 'block-positive']" @click="type='positive'">满意{{positive || ''}}</text>
                <text :class="[type === 'negative' ? 'block-negative-active' : 'block-negative']" @click="type='negative'">不满意{{negative || ''}}</text>
            </div>
            <div class="switch" @click="onlyc=!onlyc">
                <icon v-if="onlyc" class="switch-icon-fill" content="tb-round-check-fill"></icon>
                <icon v-else class="switch-icon" content="tb-round-check"></icon>
                <text class="switch-text">只看有内容的评价</text>
            </div>
        </div>

        <div class="rating-wrapper">
            <div v-for="item in lists" class="rating-item">
                <image class="rating-avatar" :src="item.avatar"></image>
                <div class="rating-content">
                    <div class="content-head">
                        <text class="head-name">{{item.username}}</text>
                        <text class="head-time">{{item.rateTime / 1000}}</text>
                    </div>
                    <div class="content-star">
                        <image v-for="i in handleInt(item.score)" class="star-star" src="../assets/images/star.png"></image>
                        <image v-for="i in 5 - handleInt(item.score)" class="star-unstar"src="../assets/images/unstar.png"></image>
                        <text class="star-delivery">{{item.deliveryTime}}</text>
                    </div>
                    <text class="content-text">{{item.text}}</text>
                    <div v-if="handleLength(item.recommend) > 0">
                        <div v-for="(recommend, rindex) in splitRecommend(item.recommend)" class="content-recommend">
                            <icon v-if="rindex === 0" class="recommend-up" content="ios-thumbs-up"></icon>
                            <text v-for="(tag, tindex) in recommend" :key="'tag_' + tindex" class="recommend-item">{{tag}}</text>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </scroller>

</template>

<style scoped>
    .comment {
        flex: 1;
    }
    .overview {
        flex-direction: row;
        align-items: center;
        padding: 36px 0;
    }
    .overview-left {
        align-items: center;
        border-right-width: 1px;
        border-right-style: solid;
        border-right-color: #d9dde1;
        padding: 12px 0;
        width: 274px;
    }
    .overview-score {
        color: #fc9153;
        font-size: 48px;
        margin-bottom: 8px;
    }
    .overview-title {
        color: #333333;
        font-size: 24px;
        margin-bottom: 10px;
    }
    .overview-rank {
        color: #999999;
        font-size: 20px;
    }
    .overview-right {
        flex: 1;
        padding: 12px 0 12px 48px;
    }
    .score-wrapper {
        flex-direction: row;
        align-items: center;
        margin-bottom: 16px;
    }
    .score-title {
        color: #333333;
        font-size: 24px;
        padding-right: 24px;
    }
    .score-star,
    .score-unstar {
        height: 30px;
        width: 30px;
        margin-left: 6px;
        margin-right: 6px;
    }
    .score-score {
        color: #fc9153;
        font-size: 24px;
        padding-left: 24px;
    }
    .score-delivery {
        color: #999999;
        font-size: 24px;
    }
    .split {
        background-color: #f3f5f7;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(7, 17, 27, .1);
        border-top-width: 1px;
        border-top-style: solid;
        border-top-color: rgba(7, 17, 27, .1);
        height: 32px;
        width: 750px;
    }
    .rating-select {
        background-color: #ffffff;
    }
    .rating-type {
        flex-direction: row;
        align-items: center;
        margin: 0 36px;
        padding: 36px 0;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(10, 24, 38, 0.1);
    }
    .block-positive,
    .block-positive-active,
    .block-negative,
    .block-negative-active {
        border-radius: 2px;
        color: #666666;
        display: inline-block;
        font-size: 24px;
        margin-right: 16px;
        padding: 16px 24px;
    }
    .block-positive,
    .block-positive-active {
        background-color: rgba(0,160,220,.2);
    }
    .block-negative,
    .block-negative-active {
        background-color: #cccccc;
    }
    .block-positive-active {
        background-color: #00a0dc;
        color: #fff;
    }
    .block-negative-active {
        background-color: #666666;
        color: #fff;
    }
    .switch {
        flex-direction: row;
        align-items: center;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(2, 6, 9, 0.1);
        padding: 24px 36px;
    }
    .switch-icon,
    .switch-icon-fill {
        width: 56px;
        height: 56px;
        font-size: 38px;
        margin-right: 2px;
        color: #999999;
    }
    .switch-icon-fill {
        color: #00b43c;
    }
    .switch-text {
        color: #999999;
        font-size: 26px;
    }
    .rating-wrapper {
        padding: 0 36px;
    }
    .rating-item {
        flex-direction: row;
        align-items: flex-start;
        padding: 36px 0 20px 0;
        border-bottom-width: 1px;
        border-bottom-style: solid;
        border-bottom-color: rgba(7, 17, 27, .1);
    }
    .rating-avatar {
        margin-right: 24px;
        width: 56px;
        height: 56px;
        border-radius: 28px;
    }
    .rating-content {
        flex: 1;
    }
    .content-head {
        flex-direction: row;
        align-items: center;
        margin-bottom: 8px;
    }
    .head-name {
        flex: 1;
        color: #333333;
        font-size: 24px;
    }
    .head-time {
        color: #999;
        font-size: 24px;
    }
    .content-star {
        flex-direction: row;
        align-items: center;
        margin-bottom: 12px;
    }
    .star-star,
    .star-unstar {
        height: 20px;
        width: 20px;
        margin-left: 3px;
        margin-right: 3px;
    }
    .star-delivery {
        padding-left: 6px;
        color: #999;
        font-size: 22px;
    }
    .content-text {
        color: #333333;
        font-size: 26px;
        margin-bottom: 16px;
    }
    .content-recommend {
        flex-direction: row;
        align-items: center;
        margin-bottom: 6px;
    }
    .recommend-up {
        width: 36px;
        height: 36px;
        color: #00a0dc;
        font-size: 32px;
        margin: 0 16px 8px 0;
    }
    .recommend-item {
        background-color: #fff;
        border-width: 1px;
        border-style: solid;
        border-color: rgba(7, 17, 27, .1);
        border-radius: 2px;
        color: #999999;
        padding: 2px 10px;
        font-size: 23px;
        margin: 0 16px 8px 0;
    }
</style>
<script>
    const eeui = app.requireModule('eeui');

    export default {
        data() {
            return {
                sellerInfo: {},

                total: 0,
                positive: 0,
                negative: 0,

                type: '',
                onlyc: false,

                lists: [],
            }
        },

        created() {
            try {
                this.sellerInfo = JSON.parse(eeui.getVariate("sellerInfo", "{}"));
            }catch (e) {

            }
            //
            this.loadComment();
        },

        watch: {
            type() {
                this.loadComment();
            }
        },

        methods: {
            loadComment() {
                eeui.ajax({
                    url: eeui.rewriteUrl("../assets/json/comment.json"),
                }, (result) => {
                    if (result.status === "success") {
                        let res = result.result;
                        if (res.ret === 1) {
                            this.total = res.data.total;
                            this.positive = res.data.positive;
                            this.negative = res.data.negative;
                            let temp = [];
                            switch (this.type) {
                                case 'positive':
                                    res.data.lists.forEach((item) => {
                                        if (item.rateType === 0) {
                                            temp.push(item);
                                        }
                                    });
                                    break;

                                case 'negative':
                                    res.data.lists.forEach((item) => {
                                        if (item.rateType === 1) {
                                            temp.push(item);
                                        }
                                    });
                                    break;

                                default:
                                    temp = res.data.lists;
                                    break;
                            }
                            this.lists = temp;
                        } else {
                            eeui.alert({
                                title: "温馨提示",
                                message: "加载商品评价失败！",
                            });
                        }
                    }
                });
            },

            splitRecommend(lists) {
                let array = [];
                let num = 2;
                let temp = [];
                lists.forEach((item) => {
                    if (num + item.length > 15) {
                        if (temp.length > 0) {
                            array.push(temp);
                        }
                        num = 0;
                        temp = [];
                    }
                    num+= item.length;
                    temp.push(item);
                });
                if (temp.length > 0) {
                    array.push(temp);
                }
                return array;
            },

            handleLength(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                if (typeof val !== "object") {
                    return 0;
                }
                return val.length || 0;
            },

            handleInt(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                val = parseInt(val);
                if (isNaN(val)) {
                    return 0;
                }
                return val || 0;
            },
        }
    }
</script>
