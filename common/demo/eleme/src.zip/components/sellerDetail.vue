<template>

    <div v-if="value" class="seller-wrapper">
        <scroller class="detail-main">
            <text class="detail-name">{{sellerInfo.name}}</text>
            <div class="detail-star-wrapper">
                <image v-for="i in handleInt(sellerInfo.score)" class="detail-star-item" src="../assets/images/star.png"></image>
                <image v-for="i in 5 - handleInt(sellerInfo.score)" class="detail-unstar-item" src="../assets/images/unstar.png"></image>
            </div>
            <div class="detail-title">
                <div class="detail-title-line"></div>
                <text class="detail-title-text">优惠信息</text>
                <div class="detail-title-line"></div>
            </div>
            <div class="detail-supports">
                <div v-for="support in sellerInfo.supports" class="detail-supports-item">
                    <image class="detail-supports-item-icon" :src="'../assets/images/supports/' + support.type + '.png'"></image>
                    <text class="detail-supports-item-text">{{support.description}}</text>
                </div>
            </div>
            <div class="detail-title">
                <div class="detail-title-line"></div>
                <text class="detail-title-text">商家公告</text>
                <div class="detail-title-line"></div>
            </div>
            <div class="detail-bulletin">
                <text class="detail-bulletin-content">{{sellerInfo.bulletin}}</text>
            </div>
        </scroller>
        <div class="detail-close">
            <icon class="detail-close-icon" content="md-close" @click="closeWin"></icon>
        </div>
    </div>

</template>

<style scoped>
    .seller-wrapper {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(7,17,27,.8);
    }
    .detail-main {
        flex: 1;
        padding: 128px 0;
    }
    .detail-name {
        color: #ffffff;
        font-size: 32px;
        font-weight: 600;
        text-align: center;
    }
    .detail-star-wrapper {
        flex-direction: row;
        align-items: center;
        justify-content: center;
        margin-top: 36px;
        padding: 4px 0;
    }
    .detail-star-item,
    .detail-unstar-item {
        width: 40px;
        height: 40px;
        margin: 0 20px;
    }
    .detail-title {
        flex-direction: row;
        align-items: center;
        justify-content: center;
        margin: 56px 75px 48px;
    }
    .detail-title-line {
        flex: 1;
        height: 1px;
        background-color: rgba(255, 255, 255, 0.4);
    }
    .detail-title-text {
        font-size: 28px;
        font-weight: 600;
        padding: 0 24px;
        color: #ffffff;
    }
    .detail-supports {
        margin: 0 75px;
    }
    .detail-supports-item {
        flex-direction: row;
        align-items: center;
        margin-bottom: 24px;
        padding: 0 24px;
    }
    .detail-supports-item-icon {
        margin-right: 12px;
        height: 32px;
        width: 32px;
    }
    .detail-supports-item-text {
        font-size: 26px;
        color: #ffffff;
    }
    .detail-bulletin {
        margin: 0 75px;
    }
    .detail-bulletin-content {
        font-size: 26px;
        padding: 0 24px;
        line-height: 42px;
        color: #ffffff;
    }
    .detail-close {
        align-items: center;
        justify-content: center;
        margin: 92px 0;
    }
    .detail-close-icon {
        font-size: 64px;
        width: 100px;
        height: 100px;
        color: #ffffff;
    }
</style>
<script>
    export default {
        name: 'sellerDetail',
        props: {
            value: {
                type: Boolean,
                default: false
            },
            sellerInfo: {
                type: Object
            },
        },

        methods: {
            handleInt(val) {
                if (typeof val === "undefined") {
                    return 0;
                }
                val = parseInt(val);
                if (isNaN(val)) {
                    return 0;
                }
                return val || 0;
            },

            closeWin() {
                this.$emit('input', false);
            }
        }
    }
</script>
